import './App.css'

function App() {
  
  return (
    <div className="App">
      <header className="header">
        <p className='white-text'>Mesa de trabalho 3</p>
      </header>
      <section className="mid">
        <h1 className='title'>Lorem Ipsum</h1>
        <p className="main-text">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque vitae lacus ut ligula mattis mattis. Duis lectus libero, efficitur quis posuere eu, volutpat id leo. Cras sed diam ac tortor pulvinar iaculis at id velit. Maecenas eget tellus ut nunc laoreet dictum. Quisque arcu mauris, accumsan sit amet suscipit vitae, sollicitudin at leo.
        </p>
        <p className="main-text">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque vitae lacus ut ligula mattis mattis. Duis lectus libero, efficitur quis posuere eu, volutpat id leo. Cras sed diam ac tortor pulvinar iaculis at id velit. Maecenas eget tellus ut nunc laoreet dictum. Quisque arcu mauris, accumsan sit amet suscipit vitae, sollicitudin at leo.
        </p>
        <p className="main-text">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque vitae lacus ut ligula mattis mattis. Duis lectus libero, efficitur quis posuere eu, volutpat id leo. Cras sed diam ac tortor pulvinar iaculis at id velit. Maecenas eget tellus ut nunc laoreet dictum. Quisque arcu mauris, accumsan sit amet suscipit vitae, sollicitudin at leo.
        </p>
        <p className='main-text'>
          Equipe: Gabriel Henrique, João Victor, Pedro Oliveira, Iraildes Vieira, Felipe Toniolo.
        </p>
      </section>
      <footer className="footer">
        <p className='white-text'>Todos os direitos reservados 2023</p>
      </footer>
      
    </div>
  )
}

export default App
